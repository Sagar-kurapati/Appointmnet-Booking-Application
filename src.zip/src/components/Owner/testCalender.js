import React, { useState, useEffect } from 'react';
import axios from 'axios';
import moment from 'moment';
import { useParams } from 'react-router-dom';

const TestCalendarPage = () => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [bookedSlots, setBookedSlots] = useState([]);
  const [error, setError] = useState(null);

  const { id: businessId, name, serviceId } = useParams(); // Get params from URL

  // Generate time slots from 11 AM to 5 PM
  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 11; hour <= 17; hour++) {
      const time = moment().hour(hour).minute(0).second(0).format('hh:mm A');
      slots.push(time);
    }
    return slots;
  };

  // Fetch booked slots for the selected date
  const fetchBookedSlots = (date) => {
    axios
      .get(`http://localhost:5000/api/bookedslots/${businessId}/${name}/${serviceId}`, { params: { date } })
      .then((response) => {
        setBookedSlots(response.data);
      })
      .catch((err) => {
        console.error('Error fetching booked slots:', err);
        setError('Failed to fetch booked slots.');
      });
  };

  // Handle date selection
  const handleDateSelect = (date) => {
    setSelectedDate(date);
    fetchBookedSlots(date);
  };

  // Check if a slot is booked
  const isSlotBooked = (slot) => {
    if (!selectedDate) return false;

    const slotStartTime = moment(`${selectedDate} ${slot}`, 'YYYY-MM-DD hh:mm A');
    const slotEndTime = moment(slotStartTime).add(1, 'hour');

    return bookedSlots.some((appointment) => {
      const bookedStart = moment(appointment.start_time);
      const bookedEnd = moment(appointment.end_time);
      return (
        slotStartTime.isBetween(bookedStart, bookedEnd, null, '[)') ||
        slotEndTime.isBetween(bookedStart, bookedEnd, null, '(]')
      );
    });
  };

  // Book an appointment
  const handleBookAppointment = (slot) => {
    if (!selectedDate) {
      setError('Please select a date first.');
      return;
    }

    const startMoment = moment(`${selectedDate} ${slot}`, 'YYYY-MM-DD hh:mm A');
    const startTime = startMoment.format('YYYY-MM-DD HH:mm:ss');
    const endTime = startMoment.add(1, 'hour').format('YYYY-MM-DD HH:mm:ss');

    const appointmentData = {
      date: selectedDate,
      startTime,
      endTime,
    };

    axios
      .post(`http://localhost:5000/api/bookappointments/${businessId}/${name}/${serviceId}`, appointmentData)
      .then((response) => {
        alert('Appointment booked successfully!');
        fetchBookedSlots(selectedDate); // Refresh booked slots
      })
      .catch((err) => {
        console.error('Error booking appointment:', err);
        setError('Failed to book the appointment.');
      });
  };

  useEffect(() => {
    if (selectedDate) {
      fetchBookedSlots(selectedDate);
    }
  }, [selectedDate]);

  return (
    <div style={styles.container}>
      <h1>Appointment Calendar</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}

      <div class="date-picker-container">
  <label for="date-input" class="date-label">Select a date:</label>
  <input
    type="date"
    id="date-input"
    onChange={(e) => handleDateSelect(e.target.value)}
    className="Date-input"
  />
</div>

      {selectedDate && (
        <div>
          <h3>Available Slots on {moment(selectedDate).format('MMMM Do YYYY')}</h3>
          <div>
            {generateTimeSlots().map((slot, index) => (
              <button
                key={index}
                onClick={() => handleBookAppointment(slot)}
                style={{
                  ...styles.slotButton,
                  backgroundColor: isSlotBooked(slot) ? 'red' : 'blue', // Red for booked, blue for available
                  cursor: isSlotBooked(slot) ? 'not-allowed' : 'pointer',
                }}
                disabled={isSlotBooked(slot)} // Disable booked slots
              >
                {slot}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    textAlign: 'center',
    marginTop: '20px',
  },
  slotButton: {
    padding: '10px 20px',
    margin: '5px',
    color: 'white',
    border: 'none',
  },
  
};

export default TestCalendarPage;
