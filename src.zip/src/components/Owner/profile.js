import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Profile = () => {
  const { userId } = useParams();
  const [business, setBusiness] = useState(null);
  const [showLogout, setShowLogout] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  // Check for token and userId on page load
  useEffect(() => {
    const token = localStorage.getItem('authToken');

    if (!token || !userId) {
      alert('Access denied. Please log in first.');
      navigate('/login');
      return;
    }

    setShowLogout(true); // Show Logout button if token exists
  }, [userId, navigate]);

  // Fetch business details
  useEffect(() => {
    const token = localStorage.getItem('authToken');

    if (!token) {
      setError('You are not authorized to view this page.');
      setLoading(false);
      return;
    }

    axios
      .get(`http://localhost:5000/api/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        setBusiness(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching business details:', error);
        setError('Failed to fetch business details.');
        setLoading(false);
      });
  }, [userId]);

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    alert('Logged out successfully!');
    navigate('/login');
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <div style={{ color: 'red' }}>{error}</div>;
  }

  if (!business) {
    return <p>Business was not found.</p>;
  }

  return (
    <div style={styles.container}>
      {/* Navigation Buttons */}
      <button style={styles.button} onClick={() => navigate(`/`)}>
        All Businesses
      </button>

      <button
        style={styles.button}
        onClick={() => navigate(`/business/${userId}/addservice`)}
      >
        Add Service
      </button>

      <button
        style={styles.button}
        onClick={() => navigate(`/business/${userId}/addEmployee`)}
      >
        Add Employee
      </button>

      {/* Logout Button */}
      {showLogout && (
        <button style={styles.button} onClick={handleLogout}>
          Logout
        </button>
      )}

      {/* Business Details */}
      <h1>{business.name}</h1>
      <p>Email: {business.email}</p>
      <p>Type: {business.type}</p>
      <p>Owner: {business.owner_name}</p>
      <p>Phone: {business.phone}</p>
    </div>
  );
};

const styles = {
  container: {
    marginTop: '50px',
    padding: '25px 50px',
  },
  button: {
    padding: '10px 20px',
    fontSize: '16px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    margin: '10px',
  },
};

export default Profile;
