import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const AddEmployee = () => {
  const { id: businessId } = useParams();
  const [name, setName] = useState('');
  const [position, setPosition] = useState('');
  const [salary, setSalary] = useState('');
  const [services, setServices] = useState([]);
  const [selectedServices, setSelectedServices] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Fetch services for the given business ID
  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/businesses/${businessId}/services`);
        setServices(response.data);
      } catch (err) {
        console.error('Error fetching services:', err);
        setError('Failed to fetch services');
      }
    };

    fetchServices();
  }, [businessId]);

  // Handle checkbox toggle for services
  const handleServiceChange = (serviceId) => {
    setSelectedServices((prevSelected) =>
      prevSelected.includes(serviceId)
        ? prevSelected.filter((id) => id !== serviceId) // Remove if already selected
        : [...prevSelected, serviceId] // Add if not selected
    );
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!name || !position || !salary || selectedServices.length === 0) {
      setError('Please fill out all fields and select at least one service');
      return;
    }

    const employeeData = {
      name,
      position,
      salary,
      businessId,
      services: selectedServices, // Array of selected service IDs
    };

    try {
      const response = await axios.post(`http://localhost:5000/api/businesses/${businessId}/addemployee`, employeeData);
      setSuccess('Employee added successfully!');
      setName('');
      setPosition('');
      setSalary('');
      setSelectedServices([]);
    } catch (err) {
      console.error('Error adding employee:', err);
      setError('Failed to add employee');
    }
  };

  return (
    <div className="register-container">
      <h2 className="register-header">Add New Employee</h2>
      <form onSubmit={handleSubmit} className="form-container">
        <input
          type="text"
          className="input-field"
          placeholder="Employee Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          className="input-field"
          placeholder="Position"
          value={position}
          onChange={(e) => setPosition(e.target.value)}
        />
        <input
          type="number"
          className="input-field"
          placeholder="Salary"
          value={salary}
          onChange={(e) => setSalary(e.target.value)}
        />

        <div className="services-container">
          <h4>Select Services:</h4>
          {services.length > 0 ? (
            services.map((service) => (
              <div key={service.id} className="service-item"> 
                <label>
                  <input
                    type="checkbox"
                    value={service.id}
                    checked={selectedServices.includes(service.id)}
                    onChange={() => handleServiceChange(service.id)}
                  />
                  {service.service_name} (${service.price}) ({service.id})
                </label>
              </div>
            ))
          ) : (
            <p>No services available</p>
          )}
        </div>

        <button type="submit" className="submit-btn">
          Add Employee
        </button>
      </form>

      {error && <p className="error-message">{error}</p>}
      {success && <p className="success-message">{success}</p>}
    </div>
  );
};

export default AddEmployee;
