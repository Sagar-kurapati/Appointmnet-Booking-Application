import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const AddServices = () => {
  const { id: businessId } = useParams(); // Extract 'id' as businessId from the URL
  const [serviceName, setServiceName] = useState('');
  const [price, setPrice] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!serviceName || !price || !businessId) {
      setError('Please fill out all required fields');
      return;
    }

    setError('');

    const serviceData = {
      serviceName,
      price,
    };

    try {
      const response = await axios.post(`http://localhost:5000/api/businesses/${businessId}/addservice`, serviceData);
      setSuccess('Service added successfully!');
      setServiceName(''); // Clear the form
      setPrice('');
    } catch (error) {
      setError('An error occurred while adding the service');
      console.error('API error:', error.response ? error.response.data : error);
    }
  };

  return (
    <div className="register-container">
      <h2 className="register-header">Add a New Service</h2>
      <form onSubmit={handleSubmit} className="form-container">
        <input
          type="text"
          className="input-field"
          placeholder="Service Name"
          value={serviceName}
          onChange={(e) => setServiceName(e.target.value)}
        />
        <input
          type="number"
          className="input-field"
          placeholder="Service Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
        <button type="submit" className="submit-btn">
          Add Service
        </button>
      </form>

      {error && <p className="error-message">{error}</p>}
      {success && <p className="success-message">{success}</p>}
    </div>
  );
};

export default AddServices;
