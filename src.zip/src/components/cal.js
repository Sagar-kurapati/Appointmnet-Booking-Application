import React, { useState, useEffect } from "react"; 
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import axios from "axios";
import { useParams } from "react-router-dom"; // Import to extract URL parameters
import "react-big-calendar/lib/css/react-big-calendar.css";

const localizer = momentLocalizer(moment);

const MyCal = () => {
  const { id } = useParams(); // Extract the business ID from the URL
  const [events, setEvents] = useState([]);
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [formData, setFormData] = useState({
    service: "",
    startDate: new Date(),
    endDate: new Date(),
  });
  const [services, setServices] = useState([]);

  // Fetch appointments and services for the specific business
  useEffect(() => {
    if (!id) return;

    // Fetch appointments for the business
    axios
      .get(`http://localhost:5000/api/businesses/${id}/appointments`) // Corrected template literal
      .then((response) => {
        const fetchedEvents = response.data.map((appointment) => ({
          title: `${appointment.service} Appointment`, // Corrected string interpolation
          start: new Date(appointment.start), // Ensure these are Date objects
          end: new Date(appointment.end),
        }));
        setEvents(fetchedEvents);
      })
      .catch((error) => {
        console.error("Error fetching appointments:", error);
      });

    // Fetch services for the business
    axios
      .get(`http://localhost:5000/api/businesses/${id}/services`) // Corrected template literal
      .then((response) => {
        setServices(response.data);
      })
      .catch((error) => {
        console.error("Error fetching business services:", error);
      });
  }, [id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();

    const newEvent = {
      title: `${formData.service} Appointment`, // Corrected string interpolation
      start: formData.startDate,
      end: formData.endDate,
    };

    // Save the appointment to the backend
    axios
      .post(`http://localhost:5000/api/businesses/${id}/appointments`, { // Corrected template literal
        service_name: formData.service,
        start_time: formData.startDate.toISOString(), // Convert to ISO string for the backend
        end_time: formData.endDate.toISOString(), // Convert to ISO string for the backend
      })
      .then((response) => {
        setEvents([...events, newEvent]);
        setShowBookingForm(false);
        setFormData({
          service: "",
          startDate: new Date(),
          endDate: new Date(),
        });
        alert(response.data.message); // Show success message
      })
      .catch((error) => {
        console.error("Error saving appointment:", error);
        alert("Error saving appointment, please try again later.");
      });
  };

  const handleSlotSelect = (slotInfo) => {
    const now = new Date();
    now.setDate(now.getDate() - 1);

    if (slotInfo.start <= now) {
      alert("You cannot book appointments in the past.");
      return;
    }

    const startDate = slotInfo.start;
    const endDate = new Date(startDate);
    endDate.setHours(startDate.getHours() + 1);

    setFormData({
      service: "",
      startDate,
      endDate,
    });
    setShowBookingForm(true);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Appointment Calendar</h2>

      {showBookingForm && (
        <div style={{ marginBottom: "20px", padding: "10px", border: "1px solid #ddd", borderRadius: "5px" }}>
          <h3>Book Appointment</h3>
          <form onSubmit={handleFormSubmit}>
            <div style={{ marginBottom: "10px" }}>
              <label>
                Select Service:
                <select
                  name="service"
                  value={formData.service}
                  onChange={handleInputChange}
                  required
                >
                  <option value="">Choose a service</option>
                  {services.map((service, index) => (
                    <option key={index} value={service.service_name}>
                      {service.service_name}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <div style={{ marginBottom: "10px" }}>
              <label>
                Start Date:
                <input
                  type="datetime-local"
                  value={moment(formData.startDate).format("YYYY-MM-DDTHH:mm")}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      startDate: new Date(e.target.value),
                    })
                  }
                  required
                />
              </label>
            </div>

            <div style={{ marginBottom: "10px" }}>
              <label>
                End Date:
                <input
                  type="datetime-local"
                  value={moment(formData.endDate).format("YYYY-MM-DDTHH:mm")}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      endDate: new Date(e.target.value),
                    })
                  }
                  required
                />
              </label>
            </div>

            <button type="submit">Confirm Appointment</button>
            <button
              type="button"
              onClick={() => setShowBookingForm(false)}
              style={{ marginLeft: "10px" }}
            >
              Cancel
            </button>
          </form>
        </div>
      )}

      <div style={{ height: "80vh" }}>
        <Calendar
          localizer={localizer}
          events={events}
          startAccessor="start"
          endAccessor="end"
          style={{ height: 500 }}
          selectable
          onSelectSlot={handleSlotSelect}
          onSelectEvent={(event) => alert(event.title)}
          views={["month", "week", "day"]}
          min={new Date()}
        />
      </div>
    </div>
  );
};

export default MyCal;
