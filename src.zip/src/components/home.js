import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import registerimg from "../images/register-img.jpg";
import rocketImage from "../images/rocket.png";
import "../css/home.css";

const Home = () => {
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showLogout, setShowLogout] = useState(false); // Track token presence for Logout button
  const navigate = useNavigate();

  // Check for token on component mount
  useEffect(() => {
    const token = localStorage.getItem("authToken");
    setShowLogout(!!token); // Show Logout button if token exists
  }, []);

  // Fetch all businesses from the backend API
  useEffect(() => {
    axios
      .get("http://localhost:5000/api/businesses")
      .then((response) => {
        console.log("Fetched successfully:", response.data); // Log the response to check
        setBusinesses(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("There was an error fetching the Businesses!", error);
        setLoading(false);
      });
  }, []);

  const handleBusinessClick = (id) => {
    navigate(`/business/${id}`);
  };

  const handleLogout = () => {
    localStorage.removeItem("authToken"); // Remove the token
    alert("Logged out successfully!");
    navigate("/login"); // Redirect to the login page
  };

  return (
    <div className="home-container">
      <div className="welcome">
        <div className="welcome-title">
          <h1 style={styles.inline}>Welcome to the Home Page!</h1>
          <p>
            This is a secure page that can only be accessed after logging in.
          </p>
        </div>

        {/* Logout Button */}
        {showLogout && (
          <button className="logout-btn" onClick={handleLogout}>
            Logout
          </button>
        )}
      </div>

      {/* Banner Image */}
      <div className="home-banner">
        <img src={registerimg} alt="Banner" className="bannerImage" />
      </div>

      {/* Business List */}
      <div>
        <h2>Business List</h2>
        {loading ? (
          <p>Loading businesses...</p>
        ) : businesses.length === 0 ? (
          <p>No Businesses available.</p>
        ) : (
          <ul>
            {businesses.map((business) => (
              <li
                key={business.id}
                className="services-listItem"
                onClick={() => handleBusinessClick(business.id)}
              >
                <div className="service-container">
                  <div className="service-icon">
                    <img src={rocketImage} alt="service-icon" />
                  </div>
                  <div className="service-content">
                    <h3>{business.name}</h3>
                    {/* -{business.email} - {business.type} - {business.owner_name} - {business.phone} */}
                    <table className="services-table">
                      <tr>
                        <td>
                          <b>Email </b>
                        </td>
                        <td>- {business.email}</td>
                      </tr>
                      <tr>
                        <td>
                          <b>Type </b>
                        </td>
                        <td>- {business.type}</td>
                      </tr>
                      <tr>
                        <td>
                          <b>Phone </b>
                        </td>
                        <td>- {business.phone}</td>
                      </tr>
                    </table>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

const styles = {
  inline: {
    margin: '0px', 
  },
};
export default Home;
