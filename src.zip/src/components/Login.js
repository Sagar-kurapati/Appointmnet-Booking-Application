import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate , Link  } from "react-router-dom";
import "../css/login.css"; // Import the CSS file
import rocketImage from "../images/rocket.png";
import loginBgImg from "../images/login-bg-img.jpg";

const UserList = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSearch = () => {
    if (!username || !password) {
      setError("Please enter a username and password");
      return;
    }

    axios
      .get(
        `http://localhost:5000/api/users/search?username=${username}&password=${password}`
      )
      .then((response) => {
        const { userId, token } = response.data;

        localStorage.setItem("authToken", token);
        localStorage.setItem("userId", userId);

        navigate(`/${userId}`);
      })
      .catch((error) => {
        if (error.response && error.response.status === 404) {
          setError("No user found with that username");
        } else if (error.response && error.response.status === 401) {
          setError("Invalid password");
        } else {
          setError("Error fetching user details");
        }
      });
  };

  return (
    <div className="login-container">
      <img src={loginBgImg} alt="Placeholder 1" class="login-img" />
      <div className="login-box">
        <h2 className="login-title">
          {" "}
          <img src={rocketImage} alt="Placeholder 1" /> Login
        </h2>
        <input
          className="login-input"
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          className="login-input"
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button className="login-button" onClick={handleSearch}>
          Login
        </button>
        {error && <p className="error-message">{error}</p>}

        <div className="extra-link">
          <Link to={`/register`} className="login-reg-link">
            Register
          </Link>
        </div>
      </div>

      <div className="footer-images">
        {/* <img src="https://via.placeholder.com/60" alt="Placeholder 2" />
        <img src="https://via.placeholder.com/60" alt="Placeholder 3" /> */}
      </div>
    </div>
  );
};

export default UserList;
