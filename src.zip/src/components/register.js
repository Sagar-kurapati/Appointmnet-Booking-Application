import React, { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import rocketImage from "../images/rocket.png";
import registerimg from "../images/register-img.jpg";

const Register = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [userCreate, setUserCreate] = useState(null);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleCreate = () => {
    if (!username || !password) {
      setError("Please enter both username and password");
      return;
    }

    setError(""); // Clear previous errors

    axios
      .post("http://localhost:5000/api/users/create", { username, password })
      .then((response) => {
        // Assuming the API responds with a 'message' and 'userId'
        if (response.data && response.data.message) {
          setUserCreate(response.data);
          navigate("/businessregister"); // Navigate to a success page or show a success message
        }
      })
      .catch((error) => {
        if (error.response) {
          setError(
            error.response.data || "An error occurred. Please try again."
          );
        } else {
          setError("Server is not responding. Please try again later.");
        }
      });
  };

  return (
    <div className="login-container">
      <img src={registerimg} alt="Placeholder 1" class="login-img" />
      <div className="login-box">
        <h2 className="login-title">
          {" "}
          <img src={rocketImage} alt="Placeholder 1" /> Register Now
        </h2>
        <input
          type="text"
          className="login-input"
          placeholder="Enter username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          className="login-input"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={handleCreate} className="login-button">
          Create
        </button>

        <div className="extra-link">
          <Link to={`/login`} className="login-reg-link">
            Login
          </Link>
        </div>
      </div>

      {/* Error message */}
      {error && <p className="error-message">{error}</p>}

      {/* Success message */}
      {userCreate && <p className="success-message">{userCreate.message}</p>}
    </div>
  );
};

export default Register;
