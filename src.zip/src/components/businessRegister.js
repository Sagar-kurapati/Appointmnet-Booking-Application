import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../css/register.css'; // Assuming the CSS file is named register.css

const BusinessRegister = () => {
  const [businessName, setBusinessName] = useState('');
  const [email, setEmail] = useState('');
  const [businessType, setBusinessType] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async () => {
    if (!businessName || !email || !businessType || !ownerName || !phone) {
      setError('Please fill out all required fields');
      return;
    }

    setError('');

    const businessData = {
      businessName,
      email,
      businessType,
      ownerName,
      phone,
    };

    // Log the data being sent to the backend for debugging
    console.log('Business Data:', businessData);

    try {
      const response = await axios.post('http://localhost:5000/api/businesses/createbusiness', businessData);
      setSuccess('Business registered successfully!');
      navigate('/home'); // Navigate to the home or list page
    } catch (error) {
      setError('An error occurred while registering the business');
      console.error('API error:', error.response ? error.response.data : error);
    }
  };

  return (
    <div className="register-container">
      <h2 className="register-header">Register Your Business</h2>
      <div className="form-container">
        <input
          type="text"
          className="input-field"
          placeholder="Business Name"
          value={businessName}
          onChange={(e) => setBusinessName(e.target.value)}
        />
        <input
          type="email"
          className="input-field"
          placeholder="Business Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="text"
          className="input-field"
          placeholder="Business Type"
          value={businessType}
          onChange={(e) => setBusinessType(e.target.value)}
        />
        <input
          type="text"
          className="input-field"
          placeholder="Owner Name"
          value={ownerName}
          onChange={(e) => setOwnerName(e.target.value)}
        />
        <input
          type="text"
          className="input-field"
          placeholder="Phone Number"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />

        <button onClick={handleSubmit} className="submit-btn">
          Register Business
        </button>
      </div>

      {error && <p className="error-message">{error}</p>}
      {success && <p className="success-message">{success}</p>}
    </div>
  );
};

export default BusinessRegister;
