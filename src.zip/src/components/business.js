import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import rocketImage from "../images/rocket.png";
import "../css/business.css";
import empimg from '../images/emp-img-1.jpg';
import empimg2 from '../images/scissors.jpg';

const Business = () => {
  const { id } = useParams();
  const [business, setBusiness] = useState(null);
  const [services, setServices] = useState([]);
  const [getemployee, setGetEmployee] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddEmployee, setShowAddEmployee] = useState(false); // Track token presence
  const [employee, setEmployee] = useState({
    name: "",
    position: "",
    salary: "",
  }); // Employee data
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("authToken");
    if (token) {
      setShowAddEmployee(true); // Show "Add Employee" section if token is present
    }
  }, []);

  useEffect(() => {
    axios
      .get(`http://localhost:5000/api/businesses/${id}`)
      .then((response) => {
        setBusiness(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching business details:", error);
        setLoading(false);
      });
  }, [id]);

  // Fetch services for the business
  useEffect(() => {
    axios
      .get(`http://localhost:5000/api/businesses/${id}/services`)
      .then((response) => {
        setServices(response.data);
      })
      .catch((error) => {
        console.error("Error fetching business services:", error);
      });
  }, [id]);

  // Fetch employees for the business
  useEffect(() => {
    axios
      .get(`http://localhost:5000/api/businesses/${id}/employees`)
      .then((response) => {
        setGetEmployee(response.data); // Replace services with employees
      })
      .catch((error) => {
        console.error("Error fetching business employees:", error);
      });
  }, [id]);

  const handleEmployeeClick = (name) => {
    navigate(`/business/${id}/${name}`);
  };

  const handleServiceClick = (name) => {
    navigate(`/business/${id}/cal`);
  };
  const handleAddEmployee = () => {
    const token = localStorage.getItem("authToken"); // Include the token in the request
    if (!token) {
      alert("You are not authorized to perform this action.");
      return;
    }

    const employeeData = { ...employee, businessId: id }; // Include businessId in the payload

    axios
      .post("http://localhost:5000/api/employees", employeeData, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        alert("Employee added successfully!");
        setEmployee({ name: "", position: "", salary: "" }); // Reset form
      })
      .catch((error) => {
        console.error("Error adding employee:", error);
        alert("Failed to add employee.");
      });
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (!business) {
    return <p>Business not found.</p>;
  }

  return (
    <div className="business-container">
      <div className="business-row">
        <div className="business-info">
          <h1>{business.name}</h1>
          <p>Email: {business.email}</p>
          <p>Type: {business.type}</p>
          <p>Owner: {business.owner_name}</p>
          <p>Phone: {business.phone}</p>
        </div>
        <div className="business-image">
          <img src={rocketImage} alt="business-image" />
        </div>
      </div>

      <div className="employee-row">
        <h2>Employees</h2>
        {getemployee.length === 0 ? ( // Using `services` state now holds employees
          <p>No employees found for this business.</p>
        ) : (
          <ul>
            {getemployee.map((employee, index) => (
              <li
                key={index}
                onClick={() => handleEmployeeClick(employee.name)}
                className="business-li"
              >
                <img
                  src={empimg}
                  alt="employee-img"
                  className="employee-img"
                />
                <h4>{employee.name}</h4>
                {employee.position}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="service-row">
        <h2>Services</h2>
        {services.length === 0 ? (
          <p>No services available for this business.</p>
        ) : (
          <ul>
            {services.map((service, index) => (
              <li key={index} className="business-li" onClick={() => handleServiceClick(service.name)}>
                <img
                  src={empimg2}
                  alt="employee-img"
                  className="employee-img"
                />
                <br></br>
                {/* <Link to={`/business/${id}/cal`}  className="service-link"> */}
                  <strong>{service.service_name} </strong>  -  ${service.price}
                {/* </Link> */}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* {showAddEmployee && (
        <div style={styles.addEmployee}>
          <h2>Add Employee</h2>
          <input
            type="text"
            placeholder="Name"
            value={employee.name}
            onChange={(e) => setEmployee({ ...employee, name: e.target.value })}
          />
          <input
            type="text"
            placeholder="Position"
            value={employee.position}
            onChange={(e) => setEmployee({ ...employee, position: e.target.value })}
          />
          <input
            type="number"
            placeholder="Salary"
            value={employee.salary}
            onChange={(e) => setEmployee({ ...employee, salary: e.target.value })}
          />
          <button style={styles.button} onClick={handleAddEmployee}>
            Add Employee
          </button>
        </div>
      )} */}
    </div>
  );
};

const styles = {
  container: {
    textAlign: "",
    marginTop: "50px",
    padding: "25px 50px",
  },
};

export default Business;
