import React, { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import axios from "axios";
import "../css/employeeDetail.css"; // Import the CSS file
import empimg2 from '../images/scissors.jpg';

const EmployeeDetail = () => {
  const { id, name } = useParams();
  const [employee, setEmployee] = useState(null);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get(`http://localhost:5000/api/businesses/${id}/employees/${name}`)
      .then((response) => {
        const fetchedEmployee = response.data;
        setEmployee(fetchedEmployee);

        const fetchServiceDetails = async () => {
          try {
            const serviceRequests = fetchedEmployee.services.map((serviceId) =>
              axios.get(`http://localhost:5000/api/services/${serviceId}`)
            );
            const serviceResponses = await Promise.all(serviceRequests);
            const fetchedServices = serviceResponses.map((res) => res.data);
            setServices(fetchedServices);
            setLoading(false);
          } catch (err) {
            setError("Failed to fetch service details.");
            setLoading(false);
          }
        };

        if (fetchedEmployee.services.length > 0) {
          fetchServiceDetails();
        } else {
          setLoading(false);
        }
      })
      .catch(() => {
        setError("Failed to fetch employee details.");
        setLoading(false);
      });
  }, [id, name]);

  const handleServiceClick = (serviceId) => {
    navigate(`/business/${id}/${name}/testcal/${serviceId}`);
  };

  if (loading) {
    return <p>Loading employee details...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  if (!employee) {
    return <p>Employee not found.</p>;
  }

  return (
    <div className="business-container">
      <div className="business-row">
        
      <h1>Employee Details</h1>
      <p>
        <strong>Name:</strong> {employee.name}
      </p>
      <p>
        <strong>Position:</strong> {employee.position}
      </p>
      <p>
        <strong>Salary:</strong> ${employee.salary}
      </p>
      <p>
        <strong>Business ID:</strong> {employee.businessId}
      </p>

      </div>
      {/* <h3>Service IDs Assigned to this Employee:</h3>
      <p>
        {employee.services.length > 0
          ? employee.services.join(", ")
          : "No services assigned"}
      </p> */}

<div className="service-row">
      <h3>Assigned Services:</h3>
      <div className="assigned-service">
        {services.length > 0 ? (
          <ul>
            {services.map((service) => (
              <li
                key={service.id}
                onClick={() => handleServiceClick(service.id)}
                className="serviceItem"
              >
                <img
                                  src={empimg2}
                                  alt="employee-img"
                                  className="employee-img"
                                />
                                <br></br>
                <strong>{service.service_name}</strong> - ${service.price}
                <p>{service.description}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p>No services assigned to this employee.</p>
        )}
      </div>

      <Link to={`/business/${id}`} className="link">
        Back to Business Details
      </Link>
    </div>

    </div>
  );
};

export default EmployeeDetail;
