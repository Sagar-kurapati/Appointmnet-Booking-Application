import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { Calendar, Views, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';

// Set the localizer for the calendar (using moment.js)
const localizer = momentLocalizer(moment);

const CalendarPage = () => {
  const [appointments, setAppointments] = useState([]); // Initialize appointments state
  const [error, setError] = useState(null); // Error state to handle failures
  const { id, name } = useParams(); // Extract URL parameters

  // Fetch appointments from the backend
  const fetchAppointments = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/fetchbook/${id}/${name}/cal`
      );
      setAppointments(response.data); // Update appointments state with fetched data
      console.log(response.data); // Log the data to verify
    } catch (err) {
      console.error('Error fetching appointments:', err);
      setError('Failed to fetch appointments.'); // Handle errors
    }
  };

  useEffect(() => {
    fetchAppointments(); // Fetch appointments when the component mounts
  }, [id, name]); // Only refetch if these params change

  // Format the appointments to fit the BigCalendar format
  const formattedAppointments = appointments.map((appointment) => ({
    title: `Service ID: ${appointment.service_id}`, // Display service ID as the title
    start: new Date(appointment.start_time), // Ensure start_time is a valid Date object
    end: new Date(appointment.end_time), // Ensure end_time is a valid Date object
  }));

  return (
    <div style={styles.container}>
      <h1>Appointment Calendar</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>} {/* Display error message if any */}

      <Calendar
        events={formattedAppointments} // Pass the formatted appointments to the Calendar component
        localizer={localizer} // Use moment localizer
        defaultView={Views.WEEK} // Set default view to week
        step={60} // Show one hour per slot
        timeslots={1} // One slot per hour
        min={new Date(2020, 0, 1, 8, 0, 0)} // Starting time for the calendar (8 AM)
        max={new Date(2020, 0, 1, 20, 0, 0)} // Ending time for the calendar (8 PM)
        onSelectEvent={(event) => alert(`Appointment details: ${event.title}`)} // Show alert on event selection
      />
    </div>
  );
};

const styles = {
  container: {
    textAlign: 'center',
    marginTop: '20px',
  },
};

export default CalendarPage;
