// frontend/src/App.js

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import UserList from './components/Login';
import Home from './components/home';
import Register from './components/register';
import BusinessRegister from './components/businessRegister';
import Business from './components/business';
import MyCal from './components/cal';
import EmployeeDetail from './components/employeeDetail';
import AddServices from './components/Owner/addservice';
import AddEmployee from './components/Owner/addEmployee';
import TestCalendarPage from './components/Owner/testCalender';
import CalendarPage from './components/universalCalendar';
import Profile from './components/Owner/profile';

function App() {
  return (
    <div className="App">
       <Router>
      <Routes>
        <Route path="/login" element={<UserList />} />
        <Route path="/register" element={<Register />} />
        <Route path="/businessregister" element={<BusinessRegister />} />
        <Route path="/business/:id" element={<Business />} />
        <Route path="/:userId" element={<Profile />} /> 
        <Route path="/" element={<Home />} />
        <Route path="/business/:id/cal" element={<MyCal />} />
        <Route path="/business/:id/addservice" element={<AddServices />} />
        <Route path="/business/:id/addEmployee" element={<AddEmployee />} />
        <Route path="/business/:id/:name" element={<EmployeeDetail />} />
        <Route path="/business/:id/:name/testcal/:serviceId" element={<TestCalendarPage />} />
        <Route path="/business/:id/:name/cal" element={<CalendarPage />} />
        {/* Add other routes as needed */}
      </Routes>
    </Router>
    </div>
  );
}

export default App;
